using System;
using Yuebon.Commons.IServices;
using Zhang.Dtos;
using Zhang.Models;

namespace Zhang.IServices
{
    /// <summary>
    /// 定义我的测试服务接口
    /// </summary>
    public interface ISys_ZhangService:IService<Sys_Zhang,Sys_ZhangOutputDto, string>
    {
    }
}
