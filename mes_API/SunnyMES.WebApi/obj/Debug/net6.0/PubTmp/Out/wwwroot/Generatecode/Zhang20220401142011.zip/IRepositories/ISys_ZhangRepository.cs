using System;
using Yuebon.Commons.IRepositories;
using Zhang.Models;

namespace Zhang.IRepositories
{
    /// <summary>
    /// 定义我的测试仓储接口
    /// </summary>
    public interface ISys_ZhangRepository:IRepository<Sys_Zhang, string>
    {
    }
}