using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using Yuebon.Commons.Models;
using Yuebon.Commons.Dtos;
using Zhang.Models;

namespace Zhang.Dtos
{
    /// <summary>
    /// 我的测试输入对象模型
    /// </summary>
    [AutoMap(typeof(Sys_Zhang))]
    [Serializable]
    public class Sys_ZhangInputDto: IInputDto<string>
    {
        /// <summary>
        /// 设置或获取 
        /// </summary>
        public string? Id { get; set; }
        /// <summary>
        /// 设置或获取 
        /// </summary>
        public string AAA { get; set; }
        /// <summary>
        /// 设置或获取 
        /// </summary>
        public string BBB { get; set; }
        /// <summary>
        /// 设置或获取 
        /// </summary>
        public int? SortCode { get; set; }
        /// <summary>
        /// 设置或获取 
        /// </summary>
        public bool? EnabledMark { get; set; }
        /// <summary>
        /// 设置或获取 
        /// </summary>
        public string Description { get; set; }

    }
}
