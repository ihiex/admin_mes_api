using System;
using Yuebon.Commons.IDbContext;
using Yuebon.Commons.Repositories;
using Zhang.IRepositories;
using Zhang.Models;

namespace Zhang.Repositories
{
    /// <summary>
    /// 我的测试仓储接口的实现
    /// </summary>
    public class Sys_ZhangRepository : BaseRepository<Sys_Zhang, string>, ISys_ZhangRepository
    {
		public Sys_ZhangRepository()
        {
        }

        public Sys_ZhangRepository(IDbContextCore context) : base(context)
        {

        }

        #region Dapper 操作

        //DapperConn 用于读写操作
        //DapperConnRead 用于只读操作

        #endregion

        
        #region EF 操作

        //DbContext 用于读写操作
        //DbContextRead 用于只读操作

        #endregion
    }
}