using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using Zhang.Models;

namespace Zhang.Dtos
{
    public class ZhangProfile : Profile
    {
        public ZhangProfile()
        {
           CreateMap<Sys_Zhang, Sys_ZhangOutputDto>();
           CreateMap<Sys_ZhangInputDto, Sys_Zhang>();

        }
    }
}
