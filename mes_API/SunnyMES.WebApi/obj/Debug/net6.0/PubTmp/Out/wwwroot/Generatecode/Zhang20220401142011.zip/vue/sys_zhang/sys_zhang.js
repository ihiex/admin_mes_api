import http from '@/utils/request'
import defaultSettings from '@/settings'

/**
   * 我的测试分页查询
   * @param {查询条件} data
   */
export function getSys_ZhangListWithPager(data) {
  return http.request({
    url: 'Sys_Zhang/FindWithPagerAsync',
    method: 'post',
    data: data,
    baseURL: defaultSettings.apiZhangUrl // 直接通过覆盖的方式
  })
}/**
   * 获取所有可用的我的测试
   */
export function getAllSys_ZhangList() {
  return http.request({
    url: 'Sys_Zhang/GetAllEnable',
    method: 'get',
    baseURL: defaultSettings.apiZhangUrl // 直接通过覆盖的方式
  })
}
/**
   * 新增或修改保存我的测试
   * @param data
   */
export function saveSys_Zhang(data, url) {
  return http.request({
    url: url,
    method: 'post',
    data: data,
    baseURL: defaultSettings.apiZhangUrl // 直接通过覆盖的方式
  })
}
/**
   * 获取我的测试详情
   * @param {Id} 我的测试Id
   */
export function getSys_ZhangDetail(id) {
  return http({
    url: 'Sys_Zhang/GetById',
    method: 'get',
    params: { id: id },
    baseURL: defaultSettings.apiZhangUrl // 直接通过覆盖的方式
  })
}
/**
   * 批量设置启用状态
   * @param {id集合} ids
   */
export function setSys_ZhangEnable(data) {
  return http({
    url: 'Sys_Zhang/SetEnabledMarktBatchAsync',
    method: 'post',
    data: data,
    baseURL: defaultSettings.apiZhangUrl // 直接通过覆盖的方式
  })
}
/**
   * 批量软删除
   * @param {id集合} ids
   */
export function deleteSoftSys_Zhang(data) {
  return http({
    url: 'Sys_Zhang/DeleteSoftBatchAsync',
    method: 'post',
    data: data,
    baseURL: defaultSettings.apiZhangUrl // 直接通过覆盖的方式
  })
}

/**
   * 批量删除
   * @param {id集合} ids
   */
export function deleteSys_Zhang(data) {
  return http({
    url: 'Sys_Zhang/DeleteBatchAsync',
    method: 'delete',
    data: data,
    baseURL: defaultSettings.apiZhangUrl // 直接通过覆盖的方式
  })
}
