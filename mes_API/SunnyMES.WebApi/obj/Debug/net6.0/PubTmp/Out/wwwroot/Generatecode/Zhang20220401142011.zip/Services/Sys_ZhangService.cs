using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Yuebon.Commons.Dtos;
using Yuebon.Commons.Mapping;
using Yuebon.Commons.Pages;
using Yuebon.Commons.Services;
using Zhang.IRepositories;
using Zhang.IServices;
using Zhang.Dtos;
using Zhang.Models;

namespace Zhang.Services
{
    /// <summary>
    /// 我的测试服务接口实现
    /// </summary>
    public class Sys_ZhangService: BaseService<Sys_Zhang,Sys_ZhangOutputDto, string>, ISys_ZhangService
    {
		private readonly ISys_ZhangRepository _repository;
        public Sys_ZhangService(ISys_ZhangRepository repository) : base(repository)
        {
			_repository=repository;
        }
    }
}